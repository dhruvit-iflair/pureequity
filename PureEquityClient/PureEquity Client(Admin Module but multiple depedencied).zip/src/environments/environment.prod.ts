export const environment = {
  production: true,
  api: 'http://139.59.86.27:6008/api',
  login: 'http://139.59.86.27:6008/login',
  register: 'http://139.59.86.27:6008/register',
  picPoint: 'http://139.59.86.27:6008/uploads',
  userDocPoint: 'http://139.59.86.27:6008/uploads/users/documents/',
  tradingApi: 'http://139.59.86.27/pureequityapi/v1'
};
