
export const environment = {
    production: false,
    api: 'http://192.168.1.37:6008/api',
    login: 'http://192.168.1.37:6008/login',
    register: 'http://192.168.1.37:6008/register',
    picPoint: 'http://192.168.1.37:6008/uploads',
    userDocPoint: 'http://192.168.1.37:6008/uploads/users/documents/',
    tradingApi: 'http://139.59.86.27/pureequityapi/v1'
  };
