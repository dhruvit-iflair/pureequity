import 'hammerjs';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DemoMaterialModule} from '../demo-material-module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ChartistModule} from 'ng-chartist';
import { ChartsModule } from 'ng2-charts';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { FileUploadModule } from 'ng2-file-upload/ng2-file-upload';
import { CKEditorModule } from 'ngx-ckeditor';

import { Dashboard1Component } from './dashboard1/dashboard1.component';
import { KycadminComponent } from './kycadmin/kycadmin.component';
import { QrotpverificationComponent } from './qrotpverification/qrotpverification.component';
import { DashboardService } from '../shared/services/dashboard.service';
import { LoginService } from '../shared/services/login.service';
import { MailerComponent } from './mailer/mailer.component';
import { MaillistComponent } from './mailer/maillist/maillist.component';
import { RolesComponent } from './roles/roles.component';
import { RoleComponent } from './roles/role/role.component';
import { NgxPayPalModule } from 'ngx-paypal';
import { AdminRoutingModule } from './admin-routing.module';
import { ChangePasswordComponent } from '../pages/change-password/change-password.component';

@NgModule({
  imports: [
    CommonModule,
    AdminRoutingModule,
    DemoMaterialModule,
    FlexLayoutModule,
    ChartistModule, 
    ChartsModule,  
    FormsModule, 
    ReactiveFormsModule,
    NgxChartsModule,
    FileUploadModule,
    CKEditorModule,
    NgxPayPalModule,
  ],
  declarations: [ 
    Dashboard1Component, 
    KycadminComponent,
    QrotpverificationComponent, 
    MailerComponent, 
    MaillistComponent, 
    RolesComponent, 
    RoleComponent,
    ChangePasswordComponent
  ],
  providers:[
    DashboardService,
    LoginService
  ]
})
export class AdminModule { }
