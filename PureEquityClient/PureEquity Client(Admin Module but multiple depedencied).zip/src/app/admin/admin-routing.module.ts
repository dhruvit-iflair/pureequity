import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Dashboard1Component } from './dashboard1/dashboard1.component';
import { KycadminComponent } from './kycadmin/kycadmin.component';
import { QrotpverificationComponent } from './qrotpverification/qrotpverification.component';
import { ChangePasswordComponent } from '../pages/change-password/change-password.component';
import { MailerComponent } from './mailer/mailer.component';
import { MaillistComponent } from './mailer/maillist/maillist.component';
import { RolesComponent } from './roles/roles.component';
import { RoleComponent } from './roles/role/role.component';

const routes: Routes = [
  { 
    path: '',
    children: [{
      path: 'dashboard', 
      component: Dashboard1Component
    },
    {
      path: 'kycadmin', 
      component: KycadminComponent
    },
    {
      path:'mails',
      component:MaillistComponent
    },
    {
      path:'mail',
      component:MailerComponent
    },
    {
      path:'mail/:id',
      component:MailerComponent
    },
    {
      path:'roles',
      component:RolesComponent
    },
    {
      path:'role',
      component:RoleComponent
    },
    {
      path:'role/:id',
      component:RoleComponent
    },
   ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
