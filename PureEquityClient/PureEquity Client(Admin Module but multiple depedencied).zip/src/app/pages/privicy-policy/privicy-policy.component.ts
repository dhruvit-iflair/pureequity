import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-privicy-policy',
  templateUrl: './privicy-policy.component.html',
  styleUrls: ['./privicy-policy.component.css']
})
export class PrivicyPolicyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
